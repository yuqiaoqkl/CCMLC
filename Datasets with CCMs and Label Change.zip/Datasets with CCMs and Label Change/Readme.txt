Instructions for CCMLC datasets.
1. Based on the original PROMISE datasets, we identify the common classes (including refactoring classes) between neighboring versions.
2. We calculate the absolute change of code metrics (CCMs) for their common classes and get new labels (lc, lu).
3. Finally, we bulid new datasets with CCMs and label change, named CCMLC.

eg. ant-1.3-1.4
The metric values are absolute change of common classes (including refactoring classes) between ant-1.3 and ant-1.4.
The label is lc or lu, where lc means label changed, and ln means label unchanged.
